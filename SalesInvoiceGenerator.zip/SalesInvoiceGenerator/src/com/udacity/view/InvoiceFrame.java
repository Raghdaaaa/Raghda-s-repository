package com.udacity.view;

//made by Raghda

import com.udacity.controller.newListener;
import com.udacity.model.InvoiceFrame1;
import com.udacity.model.FileoperationsinvHeaderTableModel;
import com.udacity.model.FileoperationsinvLineTableModel;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Closeable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.table.DefaultTableModel;

public class InvoiceFrame extends JFrame {
    private JButton createInvBtn;
    private JButton createLineBtn;
    private JTextField custNameTF;
    private JButton deleteInvBtn;
    private JButton deleteLineBtn;
    private JTextField invDateTF;
    private JTable invLineTable;
    private JLabel invNumLbl;
    private JLabel invTotalLbl;
    private JTable invoicesTable;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JMenu jMenu1;
    private JMenuBar jMenuBar1;
    private JScrollPane jScrollPane1;
    private JScrollPane jScrollPane2;
    private JMenuItem loadMenuItem;
    private JMenuItem saveMenuItem;
    private List<InvoiceFrame1> invoicesArray = new ArrayList();
    private FileoperationsinvHeaderTableModel FileoperationsinvHeaderTableModel;
    private FileoperationsinvLineTableModel FileoperationsinvLineTableModel;
    private InvoiceHeaderDialog headerDialog;
    private InvoiceLineDialog lineDialog;
    private newListener listener = new newListener(this);
    private DateFormat df = new SimpleDateFormat("dd-MM-yyyy");

    public InvoiceFrame() {
        super("Sales Invoice Generator");
        this.initComponents();
    }

    private void initComponents() {
        this.jScrollPane1 = new JScrollPane();
        this.invoicesTable = new JTable();
        this.invoicesTable.getSelectionModel().addListSelectionListener(this.listener);
        this.createInvBtn = new JButton();
        this.createInvBtn.addActionListener(this.listener);
        this.deleteInvBtn = new JButton();
        this.deleteInvBtn.addActionListener(this.listener);
        this.jLabel1 = new JLabel();
        this.jLabel2 = new JLabel();
        this.jLabel3 = new JLabel();
        this.jLabel4 = new JLabel();
        this.custNameTF = new JTextField();
        this.invDateTF = new JTextField();
        this.jLabel5 = new JLabel();
        this.invTotalLbl = new JLabel();
        this.jScrollPane2 = new JScrollPane();
        this.invLineTable = new JTable();
        this.createLineBtn = new JButton();
        this.createLineBtn.addActionListener(this.listener);
        this.deleteLineBtn = new JButton();
        this.deleteLineBtn.addActionListener(this.listener);
        this.invNumLbl = new JLabel();
        this.jMenuBar1 = new JMenuBar();
        this.jMenu1 = new JMenu();
        this.loadMenuItem = new JMenuItem();
        this.loadMenuItem.addActionListener(this.listener);
        this.saveMenuItem = new JMenuItem();
        this.saveMenuItem.addActionListener(this.listener);
        this.setDefaultCloseOperation(3);
        this.invoicesTable.setModel(new DefaultTableModel(new Object[0][], new String[0]));
        this.jScrollPane1.setViewportView(this.invoicesTable);
        this.invoicesTable.getAccessibleContext().setAccessibleName("");
        this.createInvBtn.setText("Create New Invoice");
        this.createInvBtn.setActionCommand("CreateNewInvoice");
        this.createInvBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.createInvBtnActionPerformed(evt);
            }
        });
        this.deleteInvBtn.setText("Delete Invoice");
        this.deleteInvBtn.setActionCommand("DeleteInvoice");
        this.deleteInvBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.deleteInvBtnActionPerformed(evt);
            }
        });
        this.jLabel1.setText("Invoice Number");
        this.jLabel2.setText("Invoice Date");
        this.jLabel3.setText("Customer Name");
        this.jLabel4.setText("Invoice Total");
        this.custNameTF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.custNameTFActionPerformed(evt);
            }
        });
        this.invDateTF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.invDateTFActionPerformed(evt);
            }
        });
        this.invLineTable.setModel(new DefaultTableModel(new Object[0][], new String[0]));
        this.jScrollPane2.setViewportView(this.invLineTable);
        this.createLineBtn.setText("Create New Line");
        this.createLineBtn.setActionCommand("CreateNewLine");
        this.createLineBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.createLineBtnActionPerformed(evt);
            }
        });
        this.deleteLineBtn.setActionCommand("DeleteLine");
        this.deleteLineBtn.setLabel("Delete Line");
        this.deleteLineBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.deleteLineBtnActionPerformed(evt);
            }
        });
        this.jMenu1.setText("File");
        this.loadMenuItem.setText("Load File");
        this.loadMenuItem.setActionCommand("LoadFile");
        this.loadMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.loadMenuItemActionPerformed(evt);
            }
        });
        this.jMenu1.add(this.loadMenuItem);
        this.saveMenuItem.setText("Save File");
        this.saveMenuItem.setActionCommand("SaveFile");
        this.jMenu1.add(this.saveMenuItem);
        this.jMenuBar1.add(this.jMenu1);
        this.setJMenuBar(this.jMenuBar1);
        GroupLayout layout = new GroupLayout(this.getContentPane());
        this.getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -2, 415, -2)).addGroup(layout.createSequentialGroup().addGap(46, 46, 46).addComponent(this.createInvBtn).addGap(68, 68, 68).addComponent(this.deleteInvBtn))).addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addPreferredGap(ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(Alignment.LEADING, false).addGroup(Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jLabel1, -2, 85, -2).addPreferredGap(ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.jLabel5)).addGroup(layout.createSequentialGroup().addComponent(this.invNumLbl).addGap(0, 0, 32767)))).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(Alignment.LEADING).addComponent(this.jLabel2).addComponent(this.jLabel4)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(Alignment.LEADING).addComponent(this.invTotalLbl).addComponent(this.invDateTF, -2, 242, -2))).addComponent(this.jScrollPane2, -2, 416, -2).addGroup(layout.createSequentialGroup().addComponent(this.jLabel3).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.custNameTF, -2, 242, -2)))).addGroup(layout.createSequentialGroup().addGap(72, 72, 72).addComponent(this.createLineBtn).addGap(98, 98, 98).addComponent(this.deleteLineBtn))).addContainerGap()));
        layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jLabel5).addPreferredGap(ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.jLabel1, -1, -1, 32767).addComponent(this.invNumLbl)).addGap(25, 25, 25).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.jLabel2).addComponent(this.invDateTF, -2, -1, -2)).addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(7, 7, 7).addComponent(this.jLabel3)).addGroup(layout.createSequentialGroup().addPreferredGap(ComponentPlacement.RELATED).addComponent(this.custNameTF, -2, -1, -2))).addGap(26, 26, 26).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.jLabel4).addComponent(this.invTotalLbl)).addGap(18, 18, 18).addComponent(this.jScrollPane2, -2, 201, -2).addGap(18, 18, 18).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.createLineBtn).addComponent(this.deleteLineBtn))).addComponent(this.jScrollPane1, -2, -1, -2)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(Alignment.LEADING).addComponent(this.createInvBtn).addComponent(this.deleteInvBtn)).addGap(104, 104, 104)));
        this.pack();
    }

    private void custNameTFActionPerformed(ActionEvent evt) {
    }

    private void createLineBtnActionPerformed(ActionEvent evt) {
    }

    private void deleteLineBtnActionPerformed(ActionEvent evt) {
    }

    private void invDateTFActionPerformed(ActionEvent evt) {
    }

    private void createInvBtnActionPerformed(ActionEvent evt) {
    }

    private void deleteInvBtnActionPerformed(ActionEvent evt) {
    }

    private void loadMenuItemActionPerformed(ActionEvent evt) {
    }
//look and feel code to work in different systems 
    public static void main(String[] args) {
        try {
            LookAndFeelInfo[] var1 = UIManager.getInstalledLookAndFeels();
            int var2 = var1.length;

            for(int var3 = 0; var3 < var2; ++var3) {
                LookAndFeelInfo info = var1[var3];
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException var5) {
            Logger.getLogger(InvoiceFrame.class.getName()).log(Level.SEVERE, (String)null, var5);
        } catch (InstantiationException var6) {
            Logger.getLogger(InvoiceFrame.class.getName()).log(Level.SEVERE, (String)null, var6);
        } catch (IllegalAccessException var7) {
            Logger.getLogger(InvoiceFrame.class.getName()).log(Level.SEVERE, (String)null, var7);
        } catch (UnsupportedLookAndFeelException var8) {
            Logger.getLogger(InvoiceFrame.class.getName()).log(Level.SEVERE, (String)null, var8);
        }

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                (new InvoiceFrame()).setVisible(true);
            }
        });
    }

    public newListener getListener() {
        return this.listener;
    }

    public void setInvLineTable(JTable invLineTable) {
        this.invLineTable = invLineTable;
    }

    public void setInvHeaderTableModel(FileoperationsinvHeaderTableModel FileoperationsinvHeaderTableModel) {
        this.FileoperationsinvHeaderTableModel = FileoperationsinvHeaderTableModel;
    }

    public JLabel getInvNumLbl() {
        return this.invNumLbl;
    }

    public JButton getCreateInvBtn() {
        return this.createInvBtn;
    }

    public JButton getCreateLineBtn() {
        return this.createLineBtn;
    }

    public JTextField getCustNameTF() {
        return this.custNameTF;
    }

    public JButton getDeleteInvBtn() {
        return this.deleteInvBtn;
    }

    public JButton getDeleteLineBtn() {
        return this.deleteLineBtn;
    }

    public JTextField getInvDateTF() {
        return this.invDateTF;
    }

    public JTable getInvLineTable() {
        return this.invLineTable;
    }

    public JLabel getInvTotalLbl() {
        return this.invTotalLbl;
    }

    public JTable getInvoicesTable() {
        return this.invoicesTable;
    }

    public JMenuItem getLoadMenuItem() {
        return this.loadMenuItem;
    }

    public JMenuItem getSaveMenuItem() {
        return this.saveMenuItem;
    }

    public List<InvoiceFrame1> getInvoicesArray() {
        return this.invoicesArray;
    }

    public FileoperationsinvHeaderTableModel getInvHeaderTableModel() {
        return this.FileoperationsinvHeaderTableModel;
    }

    public FileoperationsinvLineTableModel getInvLineTableModel() {
        return this.FileoperationsinvLineTableModel;
    }

    public InvoiceHeaderDialog getHeaderDialog() {
        return this.headerDialog;
    }

    public InvoiceLineDialog getLineDialog() {
        return this.lineDialog;
    }

    public void setInvLineTableModel(FileoperationsinvLineTableModel FileoperationsinvLineTableModel) {
        this.FileoperationsinvLineTableModel = FileoperationsinvLineTableModel;
    }

    public void setHeaderDialog(InvoiceHeaderDialog headerDialog) {
        this.headerDialog = headerDialog;
    }

    public void setLineDialog(InvoiceLineDialog lineDialog) {
        this.lineDialog = lineDialog;
    }
}


