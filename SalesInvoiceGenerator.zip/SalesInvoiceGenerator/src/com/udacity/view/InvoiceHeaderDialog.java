package com.udacity.view;

//made by Raghda

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class InvoiceHeaderDialog extends JDialog {
    private JTextField custNameField = new JTextField(20);
    private JTextField invDateField = new JTextField(20);
    private JLabel custNameLbl = new JLabel("Customer Name:");
    private JLabel invDateLbl = new JLabel("Invoice Date:");
    private JButton okBtn = new JButton("OK");
    private JButton cancelBtn = new JButton("Cancel");

    public InvoiceHeaderDialog(InvoiceFrame frame) {
        this.okBtn.setActionCommand("createInvOK");
        this.cancelBtn.setActionCommand("createInvCancel");
        this.okBtn.addActionListener(frame.getListener());
        this.cancelBtn.addActionListener(frame.getListener());
        this.setLayout(new GridLayout(3, 2));
        this.add(this.invDateLbl);
        this.add(this.invDateField);
        this.add(this.custNameLbl);
        this.add(this.custNameField);
        this.add(this.okBtn);
        this.add(this.cancelBtn);
        this.pack();
    }

    public JTextField getCustNameField() {
        return this.custNameField;
    }

    public JTextField getInvDateField() {
        return this.invDateField;
    }
}


