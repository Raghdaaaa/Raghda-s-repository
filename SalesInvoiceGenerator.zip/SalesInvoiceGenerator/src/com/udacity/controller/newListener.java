package com.udacity.controller;

//made by Raghda

import com.udacity.model.InvoiceFrame1;
import com.udacity.model.InvoiceLine;
import com.udacity.model.FileoperationsinvHeaderTableModel;
import com.udacity.model.FileoperationsinvLineTableModel;
import com.udacity.view.InvoiceFrame;
import com.udacity.view.InvoiceHeaderDialog;
import com.udacity.view.InvoiceLineDialog;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class newListener implements ActionListener, ListSelectionListener {
    private InvoiceFrame frame;
    private DateFormat df = new SimpleDateFormat("dd-MM-yyyy");

    public newListener(InvoiceFrame frame) {
        this.frame = frame;
    }
//the action needed when you click on the buttons and Items from Menu bar
    public void actionPerformed(ActionEvent e) {
        String var2 = e.getActionCommand();
        byte var3 = -1;
        switch(var2.hashCode()) {
            case -2008381255:
                if (var2.equals("SaveFile")) {
                    var3 = 3;
                }
                break;
            case -1740579102:
                if (var2.equals("DeleteInvoice")) {
                    var3 = 1;
                }
                break;
            case -757279831:
                if (var2.equals("CreateNewInvoice")) {
                    var3 = 0;
                }
                break;
            case -537151393:
                if (var2.equals("DeleteLine")) {
                    var3 = 5;
                }
                break;
            case -514058767:
                if (var2.equals("createInvOK")) {
                    var3 = 7;
                }
                break;
            case -176352209:
                if (var2.equals("createInvCancel")) {
                    var3 = 6;
                }
                break;
            case 595480824:
                if (var2.equals("CreateNewLine")) {
                    var3 = 4;
                }
                break;
            case 1163031978:
                if (var2.equals("createLineCancel")) {
                    var3 = 8;
                }
                break;
            case 1325100268:
                if (var2.equals("createLineOK")) {
                    var3 = 9;
                }
                break;
            case 1909829538:
                if (var2.equals("LoadFile")) {
                    var3 = 2;
                }
        }

        switch(var3) {
            case 0:
                this.displayNewInvoiceDialog();
                break;
            case 1:
                this.deleteInvoice();
                break;
            case 2:
                this.LoadFile();
                break;
            case 3:
                this.savedata();
            case 4:
                this.displayNewLineDialog();
                break;
            case 5:
                this.deleteLineBtn();
                break;
            case 6:
                this.createInvCancel();
                break;
            case 7:
                this.createInvOK();
                break;
            case 8:
                this.createLineCancel();
                break;
            case 9:
                this.createLineOK();
        }

    }
//codes needed to open file and the method for reading
    private void LoadFile() {
        JOptionPane.showMessageDialog(this.frame, "Please, select header file!", "Attention", 2);
        JFileChooser openFile = new JFileChooser();
        int result = openFile.showOpenDialog(this.frame);
        if (result == 0) {
            File headerFile = openFile.getSelectedFile();

            try {
                FileReader headerFr = new FileReader(headerFile);
                BufferedReader headerBr = new BufferedReader(headerFr);
                String headerLine = null;

                String linesLine;
                while((headerLine = headerBr.readLine()) != null) {
                    String[] headerParts = headerLine.split(",");
                    String invNumStr = headerParts[0];
                    linesLine = headerParts[1];
                    String custName = headerParts[2];
                    int invNum = Integer.parseInt(invNumStr);
                    Date invDate = this.df.parse(linesLine);
                    InvoiceFrame1 inv = new InvoiceFrame1(invNum, custName, invDate);
                    this.frame.getInvoicesArray().add(inv);
                }

                JOptionPane.showMessageDialog(this.frame, "Please, select lines file!", "Attention", 2);
                result = openFile.showOpenDialog(this.frame);
                if (result == 0) {
                    File linesFile = openFile.getSelectedFile();
                    BufferedReader linesBr = new BufferedReader(new FileReader(linesFile));
                    linesLine = null;

                    while((linesLine = linesBr.readLine()) != null) {
                        String[] lineParts = linesLine.split(",");
                        String invNumStr = lineParts[0];
                        String itemName = lineParts[1];
                        String itemPriceStr = lineParts[2];
                        String itemCountStr = lineParts[3];
                        int invNum = Integer.parseInt(invNumStr);
                        double itemPrice = Double.parseDouble(itemPriceStr);
                        int itemCount = Integer.parseInt(itemCountStr);
                        InvoiceFrame1 header = this.findInvoiceByNum(invNum);
                        InvoiceLine invLine = new InvoiceLine(itemName, itemPrice, itemCount, header);
                        header.getLines().add(invLine);
                    }

                    this.frame.setInvHeaderTableModel(new FileoperationsinvHeaderTableModel(this.frame.getInvoicesArray()));
                    this.frame.getInvoicesTable().setModel(this.frame.getInvHeaderTableModel());
                    this.frame.getInvoicesTable().validate();
                }

                System.out.println("Check");
            } catch (ParseException var21) {
                var21.printStackTrace();
                JOptionPane.showMessageDialog(this.frame, "Date Format Error\n" + var21.getMessage(), "Error", 0);
            } catch (NumberFormatException var22) {
                var22.printStackTrace();
                JOptionPane.showMessageDialog(this.frame, "Number Format Error\n" + var22.getMessage(), "Error", 0);
            } catch (FileNotFoundException var23) {
                var23.printStackTrace();
                JOptionPane.showMessageDialog(this.frame, "File Error\n" + var23.getMessage(), "Error", 0);
            } catch (IOException var24) {
                var24.printStackTrace();
                JOptionPane.showMessageDialog(this.frame, "Read Error\n" + var24.getMessage(), "Error", 0);
            }
        }

        this.displayInvoices();
    }

    private InvoiceFrame1 findInvoiceByNum(int invNum) {
        InvoiceFrame1 header = null;
        Iterator var3 = this.frame.getInvoicesArray().iterator();

        while(var3.hasNext()) {
            InvoiceFrame1 inv = (InvoiceFrame1)var3.next();
            if (invNum == inv.getInvNum()) {
                header = inv;
                break;
            }
        }

        return header;
    }

    private void savedata() {
        String headers = "";
        String lines = "";
        Iterator var3 = this.frame.getInvoicesArray().iterator();

        while(var3.hasNext()) {
            InvoiceFrame1 header = (InvoiceFrame1)var3.next();
            headers = headers + header.getDataAsCSV();
            headers = headers + "\n";

            for(Iterator var5 = header.getLines().iterator(); var5.hasNext(); lines = lines + "\n") {
                InvoiceLine line = (InvoiceLine)var5.next();
                lines = lines + line.getDataAsCSV();
            }
        }
//coed needed to save files
        JOptionPane.showMessageDialog(this.frame, "Please, select file to save header data!", "Attention", 2);
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(this.frame);
        if (result == 0) {
            File headerFile = fileChooser.getSelectedFile();

            try {
                FileWriter hFW = new FileWriter(headerFile);
                hFW.write(headers);
                hFW.flush();
                hFW.close();
                JOptionPane.showMessageDialog(this.frame, "Please, select file to save lines data!", "Attention", 2);
                result = fileChooser.showSaveDialog(this.frame);
                if (result == 0) {
                    File linesFile = fileChooser.getSelectedFile();
                    FileWriter lFW = new FileWriter(linesFile);
                    lFW.write(lines);
                    lFW.flush();
                    lFW.close();
                }

                JOptionPane.showMessageDialog((Component)null, "File Saved Successfully ! ");
            } catch (Exception var9) {
                JOptionPane.showMessageDialog(this.frame, "Error: " + var9.getMessage(), "Error", 0);
            }
        }

    }

    public void valueChanged(ListSelectionEvent e) {
        System.out.println("Invoice Selected!");
        this.invoicesTableRowSelected();
    }

    private void invoicesTableRowSelected() {
        int selectedRowIndex = this.frame.getInvoicesTable().getSelectedRow();
        if (selectedRowIndex >= 0) {
            InvoiceFrame1 row = (InvoiceFrame1)this.frame.getInvHeaderTableModel().getInvoicesArray().get(selectedRowIndex);
            this.frame.getCustNameTF().setText(row.getCustomerName());
            this.frame.getInvDateTF().setText(this.df.format(row.getInvDate()));
            this.frame.getInvNumLbl().setText("" + row.getInvNum());
            this.frame.getInvTotalLbl().setText("" + row.getInvTotal());
            ArrayList<InvoiceLine> lines = row.getLines();
            this.frame.setInvLineTableModel(new FileoperationsinvLineTableModel(lines));
            this.frame.getInvLineTable().setModel(this.frame.getInvLineTableModel());
            this.frame.getInvLineTableModel().fireTableDataChanged();
        }

    }
//deleting Invoice
    private void deleteInvoice() {
        int invIndex = this.frame.getInvoicesTable().getSelectedRow();
        InvoiceFrame1 var10000 = (InvoiceFrame1)this.frame.getInvHeaderTableModel().getInvoicesArray().get(invIndex);
        this.frame.getInvHeaderTableModel().getInvoicesArray().remove(invIndex);
        this.frame.getInvHeaderTableModel().fireTableDataChanged();
        this.frame.setInvLineTableModel(new FileoperationsinvLineTableModel(new ArrayList()));
        this.frame.getInvLineTable().setModel(this.frame.getInvLineTableModel());
        this.frame.getInvLineTableModel().fireTableDataChanged();
        this.frame.getCustNameTF().setText("");
        this.frame.getInvDateTF().setText("");
        this.frame.getInvNumLbl().setText("");
        this.frame.getInvTotalLbl().setText("");
        this.displayInvoices();
        JOptionPane.showMessageDialog((Component)null, "Invoice Deleted Successfully ! ");
    }
//deleting lines
    private void deleteLineBtn() {
        int lineIndex = this.frame.getInvLineTable().getSelectedRow();
        InvoiceLine line = (InvoiceLine)this.frame.getInvLineTableModel().getInvoiceLines().get(lineIndex);
        this.frame.getInvLineTableModel().getInvoiceLines().remove(lineIndex);
        this.frame.getInvHeaderTableModel().fireTableDataChanged();
        this.frame.getInvLineTableModel().fireTableDataChanged();
        this.frame.getInvTotalLbl().setText("" + line.getHeader().getInvTotal());
        JOptionPane.showMessageDialog((Component)null, "Line Deleted Successfully ! ");
        this.displayInvoices();
    }

    private void displayInvoices() {
        Iterator var1 = this.frame.getInvoicesArray().iterator();

        while(var1.hasNext()) {
            InvoiceFrame1 header = (InvoiceFrame1)var1.next();
            System.out.println(header);
        }

    }

    private void displayNewInvoiceDialog() {
        this.frame.setHeaderDialog(new InvoiceHeaderDialog(this.frame));
        this.frame.getHeaderDialog().setVisible(true);
    }

    private void displayNewLineDialog() {
        this.frame.setLineDialog(new InvoiceLineDialog(this.frame));
        this.frame.getLineDialog().setVisible(true);
    }

    private void createInvCancel() {
        this.frame.getHeaderDialog().setVisible(false);
        this.frame.getHeaderDialog().dispose();
        this.frame.setHeaderDialog((InvoiceHeaderDialog)null);
    }

    private void createInvOK() {
        String custName = this.frame.getHeaderDialog().getCustNameField().getText();
        String invDateStr = this.frame.getHeaderDialog().getInvDateField().getText();
        this.frame.getHeaderDialog().setVisible(false);
        this.frame.getHeaderDialog().dispose();
        this.frame.setHeaderDialog((InvoiceHeaderDialog)null);

        try {
            Date invDate = this.df.parse(invDateStr);
            int invNum = this.getNextInvoiceNum();
            InvoiceFrame1 invoiceFrame1 = new InvoiceFrame1(invNum, custName, invDate);
            this.frame.getInvoicesArray().add(invoiceFrame1);
            this.frame.getInvHeaderTableModel().fireTableDataChanged();
        } catch (ParseException var6) {
            JOptionPane.showMessageDialog(this.frame, "Wrong date Format, please adjust it ", "Error", 0);
            var6.printStackTrace();
            this.displayInvoices();
        }

    }

    private int getNextInvoiceNum() {
        int max = 0;
        Iterator var2 = this.frame.getInvoicesArray().iterator();

        while(var2.hasNext()) {
            InvoiceFrame1 header = (InvoiceFrame1)var2.next();
            if (header.getInvNum() > max) {
                max = header.getInvNum();
            }
        }

        return max + 1;
    }

    private void createLineCancel() {
        this.frame.getLineDialog().setVisible(false);
        this.frame.getLineDialog().dispose();
        this.frame.setLineDialog((InvoiceLineDialog)null);
    }

    private void createLineOK() {
        String itemName = this.frame.getLineDialog().getItemNameField().getText();
        String itemCountStr = this.frame.getLineDialog().getItemCountField().getText();
        String itemPriceStr = this.frame.getLineDialog().getItemPriceField().getText();
        this.frame.getLineDialog().setVisible(false);
        this.frame.getLineDialog().dispose();
        this.frame.setLineDialog((InvoiceLineDialog)null);
        int itemCount = Integer.parseInt(itemCountStr);
        double itemPrice = Double.parseDouble(itemPriceStr);
        int headerIndex = this.frame.getInvoicesTable().getSelectedRow();
        InvoiceFrame1 invoice = (InvoiceFrame1)this.frame.getInvHeaderTableModel().getInvoicesArray().get(headerIndex);
        InvoiceLine invoiceLine = new InvoiceLine(itemName, itemPrice, itemCount, invoice);
        invoice.addInvLine(invoiceLine);
        this.frame.getInvLineTableModel().fireTableDataChanged();
        this.frame.getInvHeaderTableModel().fireTableDataChanged();
        this.frame.getInvTotalLbl().setText("" + invoice.getInvTotal());
        this.displayInvoices();
    }
}
