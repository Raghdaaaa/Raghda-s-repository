package com.udacity;

//made by Raghda

import com.udacity.model.InvoiceFrame1;
import com.udacity.model.InvoiceLine;
import com.udacity.model.FileoperationsinvHeaderTableModel;
import com.udacity.model.FileoperationsinvLineTableModel;
import com.udacity.view.InvoiceHeaderDialog;
import com.udacity.view.InvoiceLineDialog;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class InvoiceFrame extends JFrame implements ActionListener, ListSelectionListener {
    private JButton createInvBtn;
    private JButton createLineBtn;
    private JTextField custNameTF;
    private JButton deleteInvBtn;
    private JButton deleteLineBtn;
    private JTextField invDateTF;
    private JTable invLineTable;
    private JLabel invTotalLbl;
    private JTable invoicesTable;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JMenu jMenu1;
    private JMenuBar jMenuBar1;
    private JScrollPane jScrollPane1;
    private JScrollPane jScrollPane2;
    private JMenuItem loadMenuItem;
    private JMenuItem saveMenuItem;
    private DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
    private List<InvoiceFrame1> invoicesArray = new ArrayList();
    private FileoperationsinvHeaderTableModel FileoperationsinvHeaderTableModel;
    private FileoperationsinvLineTableModel FileoperationsinvLineTableModel;
    private InvoiceHeaderDialog headerDialog;
    private InvoiceLineDialog lineDialog;

    public InvoiceFrame() {
        super("Sales Invoice Generator");
        this.initComponents();
    }

    private InvoiceFrame(int invNum, String custName, Date invDate) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private void initComponents() {
        this.jScrollPane1 = new JScrollPane();
        this.invoicesTable = new JTable();
        this.invoicesTable.getSelectionModel().addListSelectionListener(this);
        this.createInvBtn = new JButton();
        this.createInvBtn.addActionListener(this);
        this.deleteInvBtn = new JButton();
        this.deleteInvBtn.addActionListener(this);
        this.jLabel1 = new JLabel();
        this.jLabel2 = new JLabel();
        this.jLabel3 = new JLabel();
        this.jLabel4 = new JLabel();
        this.custNameTF = new JTextField();
        this.invDateTF = new JTextField();
        this.jLabel5 = new JLabel();
        this.invTotalLbl = new JLabel();
        this.jScrollPane2 = new JScrollPane();
        this.invLineTable = new JTable();
        this.createLineBtn = new JButton();
        this.createLineBtn.addActionListener(this);
        this.deleteLineBtn = new JButton();
        this.deleteLineBtn.addActionListener(this);
        this.jMenuBar1 = new JMenuBar();
        this.jMenu1 = new JMenu();
        this.loadMenuItem = new JMenuItem();
        this.loadMenuItem.addActionListener(this);
        this.saveMenuItem = new JMenuItem();
        this.saveMenuItem.addActionListener(this);
        this.setDefaultCloseOperation(3);
        this.invoicesTable.setModel(new DefaultTableModel(new Object[0][], new String[0]));
        this.jScrollPane1.setViewportView(this.invoicesTable);
        this.invoicesTable.getAccessibleContext().setAccessibleName("");
        this.createInvBtn.setText("Create New Invoice");
        this.createInvBtn.setActionCommand("CreateNewInvoice");
        this.createInvBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.createInvBtnActionPerformed(evt);
            }
        });
        //setting names and commands of buttons ,items and texts
        this.deleteInvBtn.setText("Delete Invoice");
        this.deleteInvBtn.setActionCommand("DeleteInvoice");
        this.deleteInvBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.deleteInvBtnActionPerformed(evt);
            }
        });
        this.jLabel1.setText("Invoice Number");
        this.jLabel2.setText("Invoice Date");
        this.jLabel3.setText("Customer Name");
        this.jLabel4.setText("Invoice Total");
        this.custNameTF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.custNameTFActionPerformed(evt);
            }
        });
        this.invDateTF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.invDateTFActionPerformed(evt);
            }
        });
        this.invLineTable.setModel(new DefaultTableModel(new Object[0][], new String[0]));
        this.jScrollPane2.setViewportView(this.invLineTable);
        this.createLineBtn.setText("Create New Line");
        this.createLineBtn.setActionCommand("CreateNewLine");
        this.createLineBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.createLineBtnActionPerformed(evt);
            }
        });
        this.deleteLineBtn.setActionCommand("DeleteLine");
        this.deleteLineBtn.setLabel("Delete Line");
        this.deleteLineBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                InvoiceFrame.this.deleteLineBtnActionPerformed(evt);
            }
        });
        this.jMenu1.setText("File");
        this.loadMenuItem.setText("Load File");
        this.loadMenuItem.setActionCommand("LoadFile");
        this.jMenu1.add(this.loadMenuItem);
        this.saveMenuItem.setText("Save File");
        this.saveMenuItem.setActionCommand("SaveFile");
        this.jMenu1.add(this.saveMenuItem);
        this.jMenuBar1.add(this.jMenu1);
        this.setJMenuBar(this.jMenuBar1);
        GroupLayout layout = new GroupLayout(this.getContentPane());
        this.getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -2, 415, -2)).addGroup(layout.createSequentialGroup().addGap(46, 46, 46).addComponent(this.createInvBtn).addGap(68, 68, 68).addComponent(this.deleteInvBtn))).addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addPreferredGap(ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(Alignment.LEADING, false).addGroup(Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jLabel1, -2, 85, -2).addPreferredGap(ComponentPlacement.RELATED, -1, 32767).addComponent(this.jLabel5)).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(Alignment.LEADING).addComponent(this.jLabel2).addComponent(this.jLabel4)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(Alignment.LEADING).addComponent(this.invTotalLbl).addComponent(this.invDateTF, -2, 242, -2))).addComponent(this.jScrollPane2, -2, 416, -2).addGroup(layout.createSequentialGroup().addComponent(this.jLabel3).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.custNameTF, -2, 242, -2)))).addGroup(layout.createSequentialGroup().addGap(72, 72, 72).addComponent(this.createLineBtn).addGap(98, 98, 98).addComponent(this.deleteLineBtn))).addContainerGap()));
        layout.setVerticalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jLabel5).addPreferredGap(ComponentPlacement.RELATED).addComponent(this.jLabel1, -1, -1, 32767).addGap(25, 25, 25).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.jLabel2).addComponent(this.invDateTF, -2, -1, -2)).addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(7, 7, 7).addComponent(this.jLabel3)).addGroup(layout.createSequentialGroup().addPreferredGap(ComponentPlacement.RELATED).addComponent(this.custNameTF, -2, -1, -2))).addGap(26, 26, 26).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.jLabel4).addComponent(this.invTotalLbl)).addGap(18, 18, 18).addComponent(this.jScrollPane2, -2, 201, -2).addGap(18, 18, 18).addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(this.createLineBtn).addComponent(this.deleteLineBtn))).addComponent(this.jScrollPane1, -2, -1, -2)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(Alignment.LEADING).addComponent(this.createInvBtn).addComponent(this.deleteInvBtn)).addGap(104, 104, 104)));
        this.pack();
    }

    private void custNameTFActionPerformed(ActionEvent evt) {
    }

    private void createLineBtnActionPerformed(ActionEvent evt) {
    }

    private void deleteLineBtnActionPerformed(ActionEvent evt) {
    }

    private void invDateTFActionPerformed(ActionEvent evt) {
    }

    private void createInvBtnActionPerformed(ActionEvent evt) {
    }

    private void deleteInvBtnActionPerformed(ActionEvent evt) {
    }
//reading th files
    public static void main(String[] args) {
        try {
            LookAndFeelInfo[] var1 = UIManager.getInstalledLookAndFeels();
            int var2 = var1.length;

            for(int var3 = 0; var3 < var2; ++var3) {
                LookAndFeelInfo info = var1[var3];
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException var5) {
            Logger.getLogger(InvoiceFrame.class.getName()).log(Level.SEVERE, (String)null, var5);
        } catch (InstantiationException var6) {
            Logger.getLogger(InvoiceFrame.class.getName()).log(Level.SEVERE, (String)null, var6);
        } catch (IllegalAccessException var7) {
            Logger.getLogger(InvoiceFrame.class.getName()).log(Level.SEVERE, (String)null, var7);
        } catch (UnsupportedLookAndFeelException var8) {
            Logger.getLogger(InvoiceFrame.class.getName()).log(Level.SEVERE, (String)null, var8);
        }

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                (new InvoiceFrame()).setVisible(true);
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        String var2 = e.getActionCommand();
        byte var3 = -1;
        switch(var2.hashCode()) {
            case -2008381255:
                if (var2.equals("SaveFile")) {
                    var3 = 5;
                }
                break;
            case -1740579102:
                if (var2.equals("DeleteInvoice")) {
                    var3 = 1;
                }
                break;
            case -757279831:
                if (var2.equals("CreateNewInvoice")) {
                    var3 = 0;
                }
                break;
            case -537151393:
                if (var2.equals("DeleteLine")) {
                    var3 = 3;
                }
                break;
            case -514058767:
                if (var2.equals("createInvOK")) {
                    var3 = 7;
                }
                break;
            case -176352209:
                if (var2.equals("createInvCancel")) {
                    var3 = 6;
                }
                break;
            case 595480824:
                if (var2.equals("CreateNewLine")) {
                    var3 = 2;
                }
                break;
            case 1163031978:
                if (var2.equals("createLineCancel")) {
                    var3 = 8;
                }
                break;
            case 1325100268:
                if (var2.equals("createLineOK")) {
                    var3 = 9;
                }
                break;
            case 1909829538:
                if (var2.equals("LoadFile")) {
                    var3 = 4;
                }
        }

        switch(var3) {
            case 0:
                this.displayNewInvoiceDialog();
                break;
            case 1:
                this.deleteInvoice();
                break;
            case 2:
                this.displayNewLineDialog();
                break;
            case 3:
                this.deleteLineBtn();
                break;
            case 4:
                this.LoadFile();
                break;
            case 5:
                this.savedata();
                break;
            case 6:
                this.createInvCancel();
                break;
            case 7:
                this.createInvOK();
                break;
            case 8:
                this.createLineCancel();
                break;
            case 9:
                this.createLineOK();
        }

    }
//selecting the needed file to be opened
    private void LoadFile() {
        JOptionPane.showMessageDialog(this, "Please, select header file!", "Attention", 2);
        JFileChooser openFile = new JFileChooser();
        int result = openFile.showOpenDialog(this);
        if (result == 0) {
            File headerFile = openFile.getSelectedFile();

            try {
                FileReader headerFr = new FileReader(headerFile);
                BufferedReader headerBr = new BufferedReader(headerFr);
                String headerLine = null;

                String linesLine;
                while((headerLine = headerBr.readLine()) != null) {
                    String[] headerParts = headerLine.split(",");
                    String invNumStr = headerParts[0];
                    linesLine = headerParts[1];
                    String custName = headerParts[2];
                    int invNum = Integer.parseInt(invNumStr);
                    Date invDate = this.df.parse(linesLine);
                    InvoiceFrame1 inv = new InvoiceFrame1(invNum, custName, invDate);
                    this.invoicesArray.add(inv);
                }

                JOptionPane.showMessageDialog(this, "Please, select lines file!", "Attention", 2);
                result = openFile.showOpenDialog(this);
                if (result == 0) {
                    File linesFile = openFile.getSelectedFile();
                    BufferedReader linesBr = new BufferedReader(new FileReader(linesFile));
                    linesLine = null;

                    while((linesLine = linesBr.readLine()) != null) {
                        String[] lineParts = linesLine.split(",");
                        String invNumStr = lineParts[0];
                        String itemName = lineParts[1];
                        String itemPriceStr = lineParts[2];
                        String itemCountStr = lineParts[3];
                        int invNum = Integer.parseInt(invNumStr);
                        double itemPrice = Double.parseDouble(itemPriceStr);
                        int itemCount = Integer.parseInt(itemCountStr);
                        InvoiceFrame1 header = this.findInvoiceByNum(invNum);
                        InvoiceLine invLine = new InvoiceLine(itemName, itemPrice, itemCount, header);
                        header.getLines().add(invLine);
                    }

                    this.FileoperationsinvHeaderTableModel = new FileoperationsinvHeaderTableModel(this.invoicesArray);
                    this.invoicesTable.setModel(this.FileoperationsinvHeaderTableModel);
                    this.invoicesTable.validate();
                }
            } catch (Exception var21) {
                var21.printStackTrace();
            }
        }

        this.displayInvoices();
    }
//saving data created or changed (headers and lines)
    private void savedata() {
        String headers = "";
        String lines = "";
        Iterator var3 = this.invoicesArray.iterator();

        while(var3.hasNext()) {
            InvoiceFrame1 header = (InvoiceFrame1)var3.next();
            headers = headers + header.getDataAsCSV();
            headers = headers + "\n";

            for(Iterator var5 = header.getLines().iterator(); var5.hasNext(); lines = lines + "\n") {
                InvoiceLine line = (InvoiceLine)var5.next();
                lines = lines + line.getDataAsCSV();
            }
        }

        JOptionPane.showMessageDialog(this, "Please, select file to save header data!", "Attention", 2);
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(this);
        if (result == 0) {
            File headerFile = fileChooser.getSelectedFile();

            try {
                FileWriter hFW = new FileWriter(headerFile);
                hFW.write(headers);
                hFW.flush();
                hFW.close();
                JOptionPane.showMessageDialog(this, "Please, select file to save lines data!", "Attention", 2);
                result = fileChooser.showSaveDialog(this);
                if (result == 0) {
                    File linesFile = fileChooser.getSelectedFile();
                    FileWriter lFW = new FileWriter(linesFile);
                    lFW.write(lines);
                    lFW.flush();
                    lFW.close();
                }

                JOptionPane.showMessageDialog((Component)null, "File Saved Successfully ! ");
            } catch (Exception var9) {
                JOptionPane.showMessageDialog(this, "Error: " + var9.getMessage(), "Error", 0);
            }
        }

    }

    private InvoiceFrame1 findInvoiceByNum(int invNum) {
        InvoiceFrame1 header = null;
        Iterator var3 = this.invoicesArray.iterator();

        while(var3.hasNext()) {
            InvoiceFrame1 inv = (InvoiceFrame1)var3.next();
            if (invNum == inv.getInvNum()) {
                header = inv;
                break;
            }
        }

        return header;
    }

    public void valueChanged(ListSelectionEvent e) {
        this.invoicesTableRowSelected();
    }

    private void invoicesTableRowSelected() {
        int selectedRowIndex = this.invoicesTable.getSelectedRow();
        if (selectedRowIndex >= 0) {
            InvoiceFrame1 row = (InvoiceFrame1)this.FileoperationsinvHeaderTableModel.getInvoicesArray().get(selectedRowIndex);
            this.custNameTF.setText(row.getCustomerName());
            this.invDateTF.setText(this.df.format(row.getInvDate()));
            this.jLabel1.setText("" + row.getInvNum());
            this.invTotalLbl.setText("" + row.getInvTotal());
            ArrayList<InvoiceLine> lines = row.getLines();
            this.FileoperationsinvLineTableModel = new FileoperationsinvLineTableModel(lines);
            this.invLineTable.setModel(this.FileoperationsinvLineTableModel);
            this.FileoperationsinvLineTableModel.fireTableDataChanged();
        }

    }

    private void deleteInvoice() {
        int invIndex = this.invoicesTable.getSelectedRow();
        InvoiceFrame1 var10000 = (InvoiceFrame1)this.FileoperationsinvHeaderTableModel.getInvoicesArray().get(invIndex);
        this.FileoperationsinvHeaderTableModel.getInvoicesArray().remove(invIndex);
        this.FileoperationsinvHeaderTableModel.fireTableDataChanged();
        this.FileoperationsinvLineTableModel = new FileoperationsinvLineTableModel(new ArrayList());
        this.invLineTable.setModel(this.FileoperationsinvLineTableModel);
        this.FileoperationsinvLineTableModel.fireTableDataChanged();
        this.custNameTF.setText("");
        this.invDateTF.setText("");
        this.jLabel3.setText("");
        this.invTotalLbl.setText("");
        this.displayInvoices();
        JOptionPane.showMessageDialog((Component)null, "Invoice Deleted Successfully ! ");
    }

    private void deleteLineBtn() {
        int lineIndex = this.invLineTable.getSelectedRow();
        InvoiceLine line = (InvoiceLine)this.FileoperationsinvLineTableModel.getInvoiceLines().get(lineIndex);
        this.FileoperationsinvLineTableModel.getInvoiceLines().remove(lineIndex);
        this.FileoperationsinvHeaderTableModel.fireTableDataChanged();
        this.FileoperationsinvLineTableModel.fireTableDataChanged();
        this.invTotalLbl.setText("" + line.getHeader().getInvTotal());
        JOptionPane.showMessageDialog((Component)null, "Line Deleted Successfully ! ");
        this.displayInvoices();
    }

    private void displayInvoices() {
        Iterator var1 = this.invoicesArray.iterator();

        while(var1.hasNext()) {
            InvoiceFrame1 header = (InvoiceFrame1)var1.next();
            System.out.println(header);
        }

    }

    private void displayNewInvoiceDialog() {
        com.udacity.view.InvoiceFrame InvoiceLineDialog = new com.udacity.view.InvoiceFrame();
        this.headerDialog = new InvoiceHeaderDialog(InvoiceLineDialog);
        this.headerDialog.setVisible(true);
    }

    private void displayNewLineDialog() {
        com.udacity.view.InvoiceFrame InvoiceLineDialog = new com.udacity.view.InvoiceFrame();
        this.lineDialog = new InvoiceLineDialog(InvoiceLineDialog);
        this.lineDialog.setVisible(true);
    }
//if clicked cancel for creating new Invoice
    private void createInvCancel() {
        this.headerDialog.setVisible(false);
        this.headerDialog.dispose();
        this.headerDialog = null;
    }
//codes needed for creating new Invoice then click ok
    private void createInvOK() {
        String custName = this.headerDialog.getCustNameField().getText();
        String invDateStr = this.headerDialog.getInvDateField().getText();
        this.headerDialog.setVisible(false);
        this.headerDialog.dispose();
        this.headerDialog = null;

        try {
            Date invDate = this.df.parse(invDateStr);
            int invNum = this.getNextInvoiceNum();
            InvoiceFrame1 invoiceFrame1 = new InvoiceFrame1(invNum, custName, invDate);
            this.invoicesArray.add(invoiceFrame1);
            this.FileoperationsinvHeaderTableModel.fireTableDataChanged();
        } catch (ParseException var6) {
            var6.printStackTrace();
            this.displayInvoices();
        }

    }
//getting Invoice number
    private int getNextInvoiceNum() {
        int max = 0;
        Iterator var2 = this.invoicesArray.iterator();

        while(var2.hasNext()) {
            InvoiceFrame1 header = (InvoiceFrame1)var2.next();
            if (header.getInvNum() > max) {
                max = header.getInvNum();
            }
        }

        return max + 1;
    }
//codes needed to cancel creating line
    private void createLineCancel() {
        this.lineDialog.setVisible(false);
        this.lineDialog.dispose();
        this.lineDialog = null;
    }
//codes needed to approved creating new line
    private void createLineOK() {
        String itemName = this.lineDialog.getItemNameField().getText();
        String itemCountStr = this.lineDialog.getItemCountField().getText();
        String itemPriceStr = this.lineDialog.getItemPriceField().getText();
        this.lineDialog.setVisible(false);
        this.lineDialog.dispose();
        this.lineDialog = null;
        int itemCount = Integer.parseInt(itemCountStr);
        double itemPrice = Double.parseDouble(itemPriceStr);
        int headerIndex = this.invoicesTable.getSelectedRow();
        InvoiceFrame1 invoice = (InvoiceFrame1)this.FileoperationsinvHeaderTableModel.getInvoicesArray().get(headerIndex);
        InvoiceLine invoiceLine = new InvoiceLine(itemName, itemPrice, itemCount, invoice);
        invoice.addInvLine(invoiceLine);
        this.FileoperationsinvLineTableModel.fireTableDataChanged();
        this.FileoperationsinvHeaderTableModel.fireTableDataChanged();
        this.invTotalLbl.setText("" + invoice.getInvTotal());
        this.displayInvoices();
    }
}


