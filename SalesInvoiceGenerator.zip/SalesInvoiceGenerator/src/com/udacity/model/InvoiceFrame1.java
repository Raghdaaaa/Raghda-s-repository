package com.udacity.model;

//made by Raghda

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

public class InvoiceFrame1 {
    private int invNum;
    private String customerName;
    private Date invDate;
    private ArrayList<InvoiceLine> lines;

    public InvoiceFrame1(int invNum, String customerName, Date invDate) {
        this.invNum = invNum;
        this.customerName = customerName;
        this.invDate = invDate;
    }

    public Date getInvDate() {
        return this.invDate;
    }
    public void setInvDate(Date invDate) {
        this.invDate = invDate;
    }

    public int getInvNum() {
        return this.invNum;
    }
    public void setInvNum(int invNum) {
        this.invNum = invNum;
    }

    public String getCustomerName() {
        return this.customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String toString() {
        String str = "InvoiceFram1{invNum=" + this.invNum + ", customerName=" + this.customerName + ", invDate=" + this.invDate + '}';

        InvoiceLine line;
        for(Iterator var2 = this.getLines().iterator(); var2.hasNext(); str = str + "\n\t" + line) {
            line = (InvoiceLine)var2.next();
        }

        return str;
    }

    public ArrayList<InvoiceLine> getLines() {
        if (this.lines == null) {
            this.lines = new ArrayList();
        }

        return this.lines;
    }

    public void setLines(ArrayList<InvoiceLine> lines) {
        this.lines = lines;
    }

    public double getInvTotal() {
        double total = 0.0D;
//Equation needed to calculate the total
        InvoiceLine line;
        for(Iterator var3 = this.getLines().iterator(); var3.hasNext(); total += line.getLineTotal()) {
            line = (InvoiceLine)var3.next();
        }

        return total;
    }

    public void addInvLine(InvoiceLine line) {
        this.getLines().add(line);
    }
    //Equation needed to print date
    public String getDataAsCSV() {
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        return "" + this.getInvNum() + "," + df.format(this.getInvDate()) + "," + this.getCustomerName();
    }
}
