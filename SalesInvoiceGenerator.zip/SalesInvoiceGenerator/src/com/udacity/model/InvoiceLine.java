package com.udacity.model;

//made by Raghda

import java.util.Scanner;

public class InvoiceLine {
    private String itemName;
    private double itemPrice;
    private int itemCount;
    private double lineTotal;
    private InvoiceFrame1 header;

    public InvoiceLine(String itemName, double itemPrice, int itemCount, InvoiceFrame1 header) {
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.itemCount = itemCount;
        this.header = header;
        this.setLineTotal((double)this.itemCount * this.itemPrice);
    }

    public InvoiceFrame1 getHeader() {
        return this.header;
    }

    public void setHeader(InvoiceFrame1 header) {
        this.header = header;
    }

    public String getItemName() {
        return this.itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getItemPrice() {
        return this.itemPrice;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public int getItemCount() {
        return this.itemCount;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

    public double getLineTotal() {
        return this.lineTotal;
    }

    private void setLineTotal(double lineTotal) {
        this.lineTotal = lineTotal;
    }

    public String getDataAsCSV() {
        return "" + this.getHeader().getInvNum() + "," + this.getItemName() + "," + this.getItemPrice() + "," + this.getItemCount();

    }

}
