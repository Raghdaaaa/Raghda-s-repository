package com.udacity.model;

//made by Raghda

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class FileoperationsinvHeaderTableModel extends AbstractTableModel {
    private List<InvoiceFrame1> invoicesArray;
    private DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
    public FileoperationsinvHeaderTableModel(List<InvoiceFrame1> invoicesArray) {
        this.invoicesArray = invoicesArray;
    }
    public int getRowCount() {
        return this.invoicesArray.size();
    }
    public List<InvoiceFrame1> getInvoicesArray() {
        return this.invoicesArray;
    }

    public int getColumnCount() {
        return 4;
    }
//reading columns
    public String getColumnName(int columnIndex) {
        switch(columnIndex) {
            case 0:
                return "invoice Num";
            case 1:
                return "Customer Name";
            case 2:
                return "Invoice Date";
            case 3:
                return "Invoice Total";
            default:
                return "";
        }
    }
//getting the value data
    public Object getValueAt(int rowIndex, int columnIndex) {
        InvoiceFrame1 row = (InvoiceFrame1)this.invoicesArray.get(rowIndex);
        switch(columnIndex) {
            case 0:
                return row.getInvNum();
            case 1:
                return row.getCustomerName();
            case 2:
                return this.df.format(row.getInvDate());
            case 3:
                return row.getInvTotal();
            default:
                return null;
        }
    }
//dating returning types
    public Class<?> getColumnClass(int columnIndex) {
        switch(columnIndex) {
            case 0:
                return Integer.class;
            case 1:
                return String.class;
            case 2:
                return String.class;
            case 3:
                return Double.class;
            default:
                return Object.class;
        }
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
}


