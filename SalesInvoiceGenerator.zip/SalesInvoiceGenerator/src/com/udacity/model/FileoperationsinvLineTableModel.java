package com.udacity.model;

//made by Raghda

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class FileoperationsinvLineTableModel extends AbstractTableModel {
    private List<InvoiceLine> invoiceLines;
    private DateFormat df = new SimpleDateFormat("dd-MM-yyyy");

    public FileoperationsinvLineTableModel(List<InvoiceLine> invoiceLines) {
        this.invoiceLines = invoiceLines;
    }

    public List<InvoiceLine> getInvoiceLines() {
        return this.invoiceLines;
    }

    public int getRowCount() {
        return this.invoiceLines.size();
    }

    public int getColumnCount() {
        return 4;
    }
    //reading columns
    public String getColumnName(int columnIndex) {
        switch(columnIndex) {
            case 0:
                return "Item Name";
            case 1:
                return "item Price";
            case 2:
                return "Count";
            case 3:
                return "Line Total";
            default:
                return "";
        }
    }
    //getting the value data
    public Object getValueAt(int rowIndex, int columnIndex) {
        InvoiceLine row = (InvoiceLine)this.invoiceLines.get(rowIndex);
        switch(columnIndex) {
            case 0:
                return row.getItemName();
            case 1:
                return row.getItemPrice();
            case 2:
                return row.getItemCount();
            case 3:
                return row.getLineTotal();
            default:
                return null;
        }
    }
    //dating returning types
    public Class<?> getColumnClass(int columnIndex) {
        switch(columnIndex) {
            case 0:
                return String.class;
            case 1:
                return Double.class;
            case 2:
                return Integer.class;
            case 3:
                return Double.class;
            default:
                return Object.class;
        }
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
}